import csv
from collections import defaultdict
from datetime import datetime

def read_employee_data(filename):
    employees = []
    with open(filename, mode='r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            employees.append(row)
    return employees

def extract_month(date_str):
    return datetime.strptime(date_str, "%Y-%m-%d").strftime("%B").lower()

def generate_report(filename, month, verbose=False):
    employees = read_employee_data(filename)

    birthdays = defaultdict(int)
    anniversaries = defaultdict(int)

    birthday_employees = defaultdict(list)
    anniversary_employees = defaultdict(list)

    for emp in employees:
        if extract_month(emp["birthday"]) == month:
            birthdays[emp["department"]] += 1
            if verbose:
                birthday_employees[emp["department"]].append(emp["name"])

        if extract_month(emp["hire_date"]) == month:
            anniversaries[emp["department"]] += 1
            if verbose:
                anniversary_employees[emp["department"]].append(emp["name"])

    print(f"Report for {month.capitalize()} generated")
    print("--- Birthdays ---")
    print(f"Total: {sum(birthdays.values())}")
    for dept, count in birthdays.items():
        print(f"- {dept}: {count}")
        if verbose:
            print(f"  Employees: {', '.join(birthday_employees[dept])}")
    
    print("--- Anniversaries ---")
    print(f"Total: {sum(anniversaries.values())}")
    for dept, count in anniversaries.items():
        print(f"- {dept}: {count}")
        if verbose:
            print(f"  Employees: {', '.join(anniversary_employees[dept])}")

filename = 'database.csv'  
month = 'april'  
verbose = True  

generate_report(filename, month, verbose)
