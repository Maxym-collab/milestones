import csv
import random
from faker import Faker
from datetime import datetime , timedelta

fake = Faker()
departments = ["HR" , "Finance" , "Engineering" , "R&D"]

def generate_employee_data():
    name = fake.name()
    department = random.choice(departments) 
    hire_date = fake.date_of_birth(minimum_age=22, maximum_age=50)
    birthday = fake.date_of_birth(minimum_age=22, maximum_age=50)

    return {
        "name": name,
        "hire_date": hire_date.strftime("%Y-%m-%d"),
        "department": department,
        "birthday": birthday.strftime("%Y-%m-%d")
        }
def generate_data(filename , num_employees=100):
    with open(filename , mode="w" , newline="") as file:
        writer = csv.DictWriter(file , fieldnames=["name" ,"hire_date", "department", "birthday"])
        writer.writeheader()
        for _ in range(num_employees):
            writer.writerow(generate_employee_data())

generate_data("database.csv")